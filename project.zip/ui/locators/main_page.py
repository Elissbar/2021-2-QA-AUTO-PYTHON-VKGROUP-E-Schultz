from selenium.webdriver.common.by import By


class MainPageLocators:

    username = (By.XPATH, '//*[@id="login-controls"]//ul/li[1]')
    vk_id = (By.XPATH, '//*[@id="login-controls"]//ul/li[2]')
