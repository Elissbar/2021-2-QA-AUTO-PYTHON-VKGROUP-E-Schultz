from ui.pages.base_page import BasePage
from ui.locators.main_page import MainPageLocators
import allure


class MainPage(BasePage):

    locators = MainPageLocators()
