import os

repo_root = os.path.dirname(__file__)
print(repo_root)
print(__file__)
